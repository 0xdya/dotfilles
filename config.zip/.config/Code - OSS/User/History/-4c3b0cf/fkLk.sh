#!/bin/bash
FILE=/tmp/brightness
[ ! -f $FILE ] && echo 1.0 > $FILE
CUR=$(cat $FILE)

case "$1" in
  up)
    NEW=$(echo "$CUR + 0.1" | bc)
    ;;
  down)
    NEW=$(echo "$CUR - 0.1" | bc)
    ;;
esac

if (( $(echo "$NEW > 1.0" | bc -l) )); then NEW=1.0; fi
if (( $(echo "$NEW < 0.1" | bc -l) )); then NEW=0.1; fi

echo $NEW > $FILE
gammastep -O 6500K -b $NEW &
