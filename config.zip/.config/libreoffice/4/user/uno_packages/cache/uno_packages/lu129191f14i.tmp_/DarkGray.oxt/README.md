# Dark Gray Theme for LibreOffice

Dark Gray Theme for LibreOffice.

This theme is easier on the eyes than the default black theme.

## Gallery

![Theme Writer](assets/theme-writer.png)

![Theme Calc](assets/theme-calc.png)
